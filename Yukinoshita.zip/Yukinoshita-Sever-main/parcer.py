# -*- coding: utf8 -*-
from bs4 import BeautifulSoup as BS
import requests

URL = {
    "top": 'https://yummyanime.tv/top-100/',
    "random": 'https://animego.org/anime/random',
    "schedule": 'https://animedub.ru/',
    "manga": 'https://desu.me/manga/random',
    "go": 'https://animego.org/',
    "anime": 'https://animego.org/anime/status/latest',
    "yukino": 'https://citbase.ru/characters/457-yukino-yukinosita',
}


def get_html(url):
    return requests.get(url)


def resolve_url(url):
    return requests.get(url).url


def request_filtrated_top(url):
    html = BS(url, "html.parser")
    items = html.find_all('div', class_='movie-item')
    ani = []
    for item in items:
        ani.append(
            {
                'title': item.find('div', class_='movie-item__title').get_text(strip=True)
            }
        )
    return ani


def request_filtrated_citaty(resolved_url):
    html = get_html(resolved_url)
    url = BS(html.text, "html.parser")
    text = url.find('div', class_= 'mb4').get_text(strip=True)
    list_data = [text]
    return list_data


def request_filtrated_random(resolved_url):
    html = get_html(resolved_url)
    url = BS(html.text, "html.parser")
    image = url.find_all('img')
    line = url.find('div', class_='description pb-3').get_text(strip=True)
    gen = url.find('dd', class_ = 'col-6 col-sm-8 mb-1 overflow-h').get_text(strip=True)
    list_data = [image[2].attrs['src'], image[2].attrs['title'], line, resolved_url,gen]
    return list_data


def request_filtrated_manga(resolved_url):
    html = get_html(resolved_url)
    url = BS(html.text, "html.parser")
    image = url.find_all('img')
    title = url.find('div', class_='titleBar').get_text(strip=True)
    description = url.find('div', class_='prgrph').get_text(strip=True)
    key = url.find('div', class_='line').find('div', class_='value').get_text(strip=True)
    stat = url.find('span', class_='b-anime_status_tag').get_text(strip=True)
    gen = url.find('ul', class_='tagList').get_text(separator=" ",strip=True)
    list_data = [title, image[0].attrs['src'], description, resolved_url, key, gen, stat]
    return list_data


def data(type_of):
    if type_of == "top":
        return request_filtrated_top(get_html(URL["top"]).text)
    if type_of == 'manga':
        return request_filtrated_manga(resolve_url(URL["manga"]))
    if type_of == "random":
        return request_filtrated_random(resolve_url(URL["random"]))
