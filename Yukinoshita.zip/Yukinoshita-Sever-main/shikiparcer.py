import requests
from bs4 import BeautifulSoup as BS
url = "https://shikimori.one/"
headers = {'User-Agent': 'Mozilla/5.0 (compatible; Googlebotint/2.1; +http://www.google.com/botint.html)'}

def shiki():
    response = requests.get(url = url, headers=headers)
    if response.status_code == 200:
        soup = BS(response.content, "html.parser")
        data = soup.findAll("article", class_ = "b-news_wall-topic")
        title = data[0].contents[1].get("content")
        link = data[0].contents[3].get("content")
        image = data[0].img.get("src")
        return [title,link,image]
    else:
        print("Ошибка")