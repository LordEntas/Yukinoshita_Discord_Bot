# -*- coding: utf8 -*-
import random
import json
from bs4 import BeautifulSoup as BS
from disnake.ext import commands
from disnake.ui import Button, View
import requests
import disnake
import config
import parcer
import sqlite3


headers = {'User-Agent': 'Mozilla/5.0 (compatible; Googlebotint/2.1; +http://www.google.com/botint.html)'}
intents = disnake.Intents.all()
intents.members = True
botintint = commands.InteractionBot()
conn = sqlite3.connect("channels.db")
cursor = conn.cursor()
bot = commands.Bot(command_prefix="!", case_insensitive=True, intents=intents)

cursor.execute("""CREATE TABLE IF NOT EXISTS channel(
    channel_id INT,
    server_id INT);
""")
conn.commit()



# Команды
@botintint.slash_command(description="Список доступных команд:")
async def help(inter):
    embed = disnake.Embed(title="**Список доступных команд:**", description="\n **/neko - Кидает картинку с кошкодевочкой**\n **/cat - Кидает картинку с кошкомальчиком**\n **/quotes - Кидает цитату из аниме**\n **/search - Поиск аниме по жанру**\n **/rani - Выдает рандомное аниме**\n **/rman - Выдает рандомную мангу**\n **/anime - Поиск нужного Вам аниме**\n **/hug - Обнять пользователя**\n **/kiss - Поцеловать пользователя**\n")
    await inter.response.send_message(embed=embed)


@botintint.slash_command(description="Установить канал для сбора новостей с shikimori.one")
async def setchannel(inter):
    server = inter.guild.id
    channel_id = inter.channel.id
    for row in cursor.execute(f"SELECT channel_id FROM channel where server_id = {server}"):
        print(row[0])
        if row[0] == None or row[0] == 0:
            cursor.execute(f"UPDATE channel SET channel_id = {channel_id} where server_id = {server}")
            conn.commit()
            await inter.response.send_message("Данный канал установлен, как канал для сбора новостей с shikimori.one!")
        else:
            button_yes = Button(
                label = "Да", 
                style=disnake.ButtonStyle.green
                ) 
            button_no = Button(
                label = "Нет",
                style=disnake.ButtonStyle.red
            )
            view = View()
            view.add_item(button_yes)
            view.add_item(button_no)        
            await inter.response.send_message("У вас уже есть канал, который используется для сбора новостей с shikimori.one!\nХотите переназначить канал?", view=view)
            async def button_callback_yes(inter):
                cursor.execute(f"UPDATE channel SET channel_id = {channel_id} where server_id = {server}")
                conn.commit()
                await inter.response.send_message("Данный канал установлен, как канал для сбора новостей с shikimori.one!")
            async def button_callback_no(inter):
                await inter.response.send_message("Всего доброго)")
            button_yes.callback = button_callback_yes
            button_no.callback = button_callback_no




@botintint.slash_command(description="Сейфбуру")
async def safe(inter, теги):
    теги = str(теги).replace(" ", "+")
    #n = 0  # Для будущего пагинатора
    try:
        r = requests.get(f"https://safebooru.org/index.php?page=dapi&limit=359&s=post&q=index&json=1&tags={теги}").json()
        n = random.randint(1, len(r)-1)
        await inter.response.send_message(f"https://safebooru.org/images/{r[n]['directory']}/{r[n]['image']}")
    except:
        await inter.response.send_message("Такого тега не существует!", ephemeral=True)


@botintint.slash_command(description="Кидает картинку с кошкодевочкой")
async def neko(inter):
    resp = requests.get("https://nekos.best/api/v2/neko")
    await inter.response.send_message(resp.json()["results"][0]["url"])


@botintint.slash_command(description="Кидает картинку с кошкомальчиком")
async def cat(inter):
    response = requests.get("https://api.catboys.com/img").text
    await inter.response.send_message(json.loads(response)["url"])


@botintint.slash_command(description="Кидает цитату из аниме")
async def quotes(inter):
    api = "https://animechan.vercel.app/api/random"
    data = requests.get(api)
    newdata = data.text
    python_data = json.loads(newdata)
    anime = python_data["anime"]
    char = python_data["character"]
    quote = python_data["quote"]
    embed = disnake.Embed(title=f"**Цитата *{char}* из аниме *{anime}***", description=f"**{quote}**")
    await inter.response.send_message(embed=embed)


@botintint.slash_command(description="Поиск аниме по указаному жанру")
async def search(inter, жанр):
    c = []
    for item in range(0, 6):
        url = f"https://aniu.ru/anime/genres/{жанр}"
        r = requests.get(url + f"?page={item}&", headers=headers)
        c.append(r)
    if r.status_code == 200:
        def parse():
            rand = random.choice(c)
            soup = BS(rand.content, "html.parser")
            hre = soup.find_all('a', class_='info')
            if not hre:
                return parse()
            else:
                return hre
        a = parse()
        arrhre = []
        for x in a:
            arrhre.append(x.get("href"))
        data = random.choice(arrhre)
        ln = "https://aniu.ru/"
        await inter.response.send_message(f"**Тебе стоит посмотреть: {ln + data}**")
    else:
        await inter.response.send_message("**Произошла ошибка. Возможно, сайт не доступен. Проверьте, правильно ли вы указали название жанра. Оно должно совпадать со списком ниже.**")
        await inter.response.send_message("**Доступные жанры: \nСейнен\nСёдзе\nКомедия\nРомантика\nШкола\nБезумие\nБоевые искусства\nВампиры\nВоенное\nГарем\nДемоны\nДетектив\nДрама\nДетское\nИгры\nИсторический\nКосмос\nМагия\nМашины\nМеха\nМузыка\nПародия\nПовседневность\nПолиция\nПриключения\nПсихологическое\nСамураи\nСверхъествественное\nСпорт\nСупер сила\nУжасы\nФантастика\nФэнтези\nЭкшен\nТриллер**")


@botintint.slash_command(description="Находит рандомное аниме")
async def rani(inter):
    temp = parcer.data("random")
    embed = disnake.Embed(
        color=inter.guild.me.top_role.color,
        title=temp[1],
        url=temp[3],
    )
    embed.set_image(url=temp[0])
    embed.add_field(name='Описание', value=f'**{temp[2][:200]}...\n**')
    embed.add_field(name='Жанры', value=f'**{temp[4]}**', inline=False)
    await inter.response.send_message(embed=embed)


@botintint.slash_command(description="Находит рандомную мангу")
async def rman(inter):
    temp = parcer.data("manga")
    embed = disnake.Embed(
        color=inter.guild.me.top_role.color,
        title=temp[0],
        url=temp[3],
    )
    embed.add_field(name='Тип', value=f'**{temp[4]}**\n', inline=False)
    embed.add_field(name='Жанры', value=f'**{temp[5]}**\n', inline=True)
    embed.add_field(name='Статус', value=f'**{temp[6]}**', inline=False)
    embed.set_image(url='https://desu.me' + temp[1])
    embed.add_field(name='Описание', value=f"**{temp[2][:200]}...**", inline=False)
    await inter.response.send_message(embed=embed)


@botintint.slash_command(description="Обнимает кого либо")
async def hug(inter, member: disnake.Member = None):
    if member is None:
        return
    await inter.response.send_message(f"{inter.author.mention} обнял {member.mention}")
    await inter.response.send_message(random.choice(config.hug))


@botintint.slash_command(description="Поцеловать кого-либо")
async def kiss(inter, member: disnake.Member = None):
    if member is None:
        return
    await inter.response.send_message(f"{inter.author.mention} поцеловал {member.mention}")
    await inter.response.send_message(random.choice(config.kiss))


@botintint.slash_command(description="Очистка чата")
@commands.has_permissions(administrator=True)
async def clear(defer, number: int):
    await defer.channel.purge(limit=number)
    await defer.response.send_message(f"Очистка чата завершена. Удалено {number} сообщений(я)!")


@botintint.slash_command(description="Удаление сообщений пользователя")
@commands.has_permissions(administrator=True)
async def dlt(defer, user: disnake.Member or id):
    await defer.channel.purge(limit=None, check=lambda m: m.author == user)
    await defer.response.send_message(f"Все сообщения {disnake.Member} были удалены!")


@botintint.slash_command(description="Находит аниме")
async def anime(inter, название):
    textToSearch = название
    response = requests.get(url='https://animego.org/search/all?q=', params={'q': textToSearch}, headers=headers)
    soup = BS(response.content, 'html.parser')
    if response.status_code == 200:
        try:
            data = soup.find('div', class_='h5 font-weight-normal mb-2 card-title text-truncate').find('a').get('href')
            title = soup.find('div', class_='h5 font-weight-normal mb-2 card-title text-truncate').find('a').get('title')
            soup = BS(requests.get(data).content, 'html.parser')
            image = soup.find('div', class_='anime-poster position-relative cursor-pointer').find('img').get('src')
            discription = soup.find('div', 'description pb-3').get_text(strip=True)
            gen = soup.find('dd', class_='col-6 col-sm-8 mb-1 overflow-h').get_text(strip=True)
            variable = data, image, title, discription
            embed = disnake.Embed(
                title=variable[2],
                url=data, description=variable[3][:200] + "...",
                color=inter.guild.me.top_role.color,
            )
            embed.add_field(name="Жанры: ", value=gen)
            embed.set_image(url=variable[1])
            await inter.response.send_message(embed=embed)
        except AttributeError:
            await inter.response.send_message("Аниме нет в базе данных AnimeGo!")
    else:
        await inter.response.send_message("Нет доступа к сайту")


# Ивенты

@botintint.event 
async def on_ready():
    #botintint.loop.create_task(shikimory())
    print(config.author)
    await botintint.change_presence(status=disnake.Status.online, activity=disnake.Game('Романтическую жизнь'))
    guild_id = botintint.guilds
    for guild in guild_id: # Заполнение БД 
        cursor.execute(f"SELECT channel_id FROM channel where server_id={guild.id}")
        if cursor.fetchone() is None:
            cursor.execute(
                f"INSERT INTO channel VALUES (0,{guild.id} )"
            )
        else:
            pass
        conn.commit()

@botintint.event
async def on_error(event, *args):
    with open('err.log', 'a') as f:
        if event == 'on_message':
            f.write(f"Невыполенное сообщение: {args[0]}\n")
        else:
            raise

@botintint.event
async def on_command_error(inter, error):
    if isinstance(error, commands.errors.CheckFailure):
        await inter.response.send_message('У тебя нет прав.')


# Запуск
botintint.run(config.token)
botintint._run_event()
