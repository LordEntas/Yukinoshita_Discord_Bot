token = "TOKEN"
author = "NAME"
prefix = "YOUR PREFIX"
gifs = ["https://tenor.com/view/mashiro-mikakunin-de-shinkoukei-dance-gif-20328068",
        "https://tenor.com/view/tsumugi-shirogane-danganronpa-v3-random-gif-23173337",
        "https://tenor.com/view/anime-weird-random-gif-5956204",
        'https://tenor.com/view/anime-gif-10117765',
        'https://tenor.com/view/yandere-tagged-knife-anime-gif-16524623',
        'https://tenor.com/view/bang-funny-gun-handgun-anime-gif-18332168',
        'https://tenor.com/view/mai-sakurajima-mai-mai-san-bunny-girl-sen-bunny-girl-gif-23760652',
        'https://tenor.com/view/funny-face-anime-gif-14294759',
        'https://tenor.com/view/anime-blush-cute-so-adorable-gif-11807436',
        'https://tenor.com/view/wanna-watch-anime-watch-anime-anime-want-to-watch-anime-gif-21612524',
        'https://tenor.com/view/animekiziagliyo-gif-23279305',
        'https://tenor.com/view/anime-anime-girl-anime-girl-dancing-cute-anime-girls-anime-girls-vibing-gif-24110099',
        'https://tenor.com/view/ara-anime-eyebrow-up-gif-15721758',
        'https://tenor.com/view/kasumi-bang-dream-bandori-hi-meow-gif-22659490'
        ]
hug = [
    "https://tenor.com/bC3Ti.gif",
    "https://tenor.com/bC3Ti.gif",
    "https://tenor.com/bpL5k.gif"
]
kiss = [
    "https://tenor.com/buefo.gif",
    "https://tenor.com/bk57E.gif",
    "https://tenor.com/bIDCb.gif",
    "https://tenor.com/bmDbX.gif"
]


